#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main (void)
{
   pid_t daemon_pid;

   daemon_pid = fork();

   if (daemon_pid < 0)
   {
      printf("FORK FAILURE!\n");
      exit(EXIT_FAILURE);
   }

   if (daemon_pid > 0)
   {
      exit(EXIT_SUCCESS);
   }

   printf("hello daemon\n");
}
